"""Метрики calculator.py; только стандартная библиотека Python."""
import ast
import hashlib
import io
import json
from pathlib import Path
import platform
import sys
import tokenize


def measure(path):
    raw = path.read_bytes()
    text = raw.decode('utf-8-sig')
    lines = text.splitlines()
    tree = ast.parse(text)
    nodes = list(ast.walk(tree))
    doc_lines = set()
    for node in nodes:
        if isinstance(node, (ast.Module, ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            if node.body and isinstance(node.body[0], ast.Expr):
                value = node.body[0].value
                if isinstance(value, ast.Constant) and isinstance(value.value, str):
                    doc_lines.update(range(node.body[0].lineno, node.body[0].end_lineno + 1))
    comments, code = set(), set()
    ignored = {tokenize.ENCODING, tokenize.ENDMARKER, tokenize.NEWLINE,
               tokenize.NL, tokenize.INDENT, tokenize.DEDENT}
    for token in tokenize.generate_tokens(io.StringIO(text).readline):
        if token.type == tokenize.COMMENT:
            comments.add(token.start[0])
        elif token.type not in ignored:
            code.update(range(token.start[0], token.end[0] + 1))
    # Для данного файла docstring занимает отдельную строку; пересечений нет.
    code -= doc_lines
    comment_only = comments - code - doc_lines
    blank = {i for i, line in enumerate(lines, 1) if not line.strip()}
    assert not (blank & (code | doc_lines | comment_only))
    assert len(lines) == len(blank) + len(code) + len(doc_lines) + len(comment_only)
    def decisions(scope):
        result = []
        for n in ast.walk(scope):
            if isinstance(n, ast.If):
                result.append((n.lineno, 'if/elif', 1))
            elif isinstance(n, (ast.For, ast.While, ast.AsyncFor)):
                result.append((n.lineno, 'loop', 1))
            elif isinstance(n, ast.ExceptHandler):
                result.append((n.lineno, 'except', 1))
            elif isinstance(n, ast.BoolOp):
                result.append((n.lineno, 'and/or', len(n.values) - 1))
        return sorted(result)
    main = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'main')
    module_scope = ast.Module(body=[n for n in tree.body if not isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef))], type_ignores=[])
    module_decisions = decisions(module_scope)
    main_decisions = decisions(main)
    elif_count = sum(line.lstrip().startswith('elif ') for line in lines)
    if_count = sum(isinstance(n, ast.If) for n in nodes)
    modules = set()
    for n in nodes:
        if isinstance(n, ast.Import):
            modules.update(a.name for a in n.names)
        elif isinstance(n, ast.ImportFrom):
            modules.add(n.module or '')
    return dict(sha256=hashlib.sha256(raw).hexdigest(), LOC=len(lines),
                nonempty=len(lines)-len(blank), SLOC=len(code), blank=len(blank),
                comments=len(comment_only), docstring=len(doc_lines),
                blank_lines=sorted(blank), code_lines=sorted(code),
                functions=sum(isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) for n in nodes),
                loops=sum(isinstance(n, (ast.For, ast.While, ast.AsyncFor)) for n in nodes),
                if_count=if_count-elif_count, elif_count=elif_count, if_elif=if_count,
                conditional_chains=if_count-elif_count,
                handlers=sum(isinstance(n, ast.ExceptHandler) for n in nodes),
                imports=sorted(modules), main_decisions=main_decisions,
                main_complexity=1+sum(x[2] for x in main_decisions),
                module_decisions=module_decisions,
                module_complexity=1+sum(x[2] for x in module_decisions))


if __name__ == '__main__':
    path = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).with_name('calculator.py')
    result = measure(path)
    previous = json.loads(Path(__file__).with_name('lr3_results.json').read_text(encoding='utf-8'))
    groups = {}
    for run in previous['runs']:
        groups.setdefault(run['id'], []).append(run['passed'])
    result['LR3'] = dict(cases=len(groups), passed_cases=sum(all(g) for g in groups.values()),
                         launches=len(previous['runs']), passed_launches=sum(r['passed'] for r in previous['runs']))
    result['environment'] = dict(python=platform.python_version(), platform=platform.system())
    print(json.dumps(result, ensure_ascii=False, indent=2))
