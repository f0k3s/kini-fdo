"""Функциональные проверки консольного приложения; только стандартная библиотека."""
import datetime
import json
import os
from pathlib import Path
import platform
import re
import subprocess
import sys
import unittest

ROOT = Path(__file__).resolve().parent
CASES = json.loads((ROOT / 'test_cases.json').read_text(encoding='utf-8'))
RUNS = []

class CalculatorTests(unittest.TestCase):
    def check_case(self, case):
        for index, variant in enumerate(case['variants'], 1):
            with self.subTest(variant=index):
                env = dict(os.environ, PYTHONIOENCODING='utf-8', PYTHONUTF8='1')
                proc = subprocess.run(
                    [sys.executable, str(ROOT / 'calculator.py')],
                    input=variant['input'], text=True, encoding='utf-8',
                    capture_output=True, timeout=5, env=env,
                )
                results = re.findall(r'Результат: ([^\r\n]+)', proc.stdout)
                errors = re.findall(r'Ошибка: ([^\r\n]+)', proc.stdout)
                passed = (proc.returncode == 0 and proc.stderr == ''
                          and results == variant['results'] and errors == variant['errors']
                          and proc.stdout.count('Работа завершена.') == 1)
                RUNS.append(dict(id=case['id'], variant=index, name=case['name'],
                                 input=variant['input'], stdout=proc.stdout,
                                 stderr=proc.stderr, returncode=proc.returncode,
                                 results=results, errors=errors, passed=passed))
                self.assertEqual(proc.returncode, 0)
                self.assertEqual(proc.stderr, '')
                self.assertEqual(results, variant['results'])
                self.assertEqual(errors, variant['errors'])
                self.assertEqual(proc.stdout.count('Работа завершена.'), 1)
                self.assertNotIn('Traceback', proc.stdout)

def make_test(case):
    def test(self):
        self.check_case(case)
    test.__doc__ = case['name']
    return test

for case in CASES:
    setattr(CalculatorTests, 'test_' + case['id'], make_test(case))

if __name__ == '__main__':
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(CalculatorTests)
    with (ROOT / 'unittest_output.txt').open('w', encoding='utf-8') as log:
        result = unittest.TextTestRunner(stream=log, verbosity=2).run(suite)
    metadata = dict(timestamp=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                    python=sys.version, platform=platform.platform(),
                    cases=result.testsRun, launches=len(RUNS),
                    passed_launches=sum(x['passed'] for x in RUNS),
                    failures=len(result.failures), errors=len(result.errors),
                    success=result.wasSuccessful())
    (ROOT / 'results.json').write_text(json.dumps(dict(environment=metadata,runs=RUNS),
                                    ensure_ascii=False,indent=2),encoding='utf-8')
    with (ROOT / 'console_transcripts.txt').open('w',encoding='utf-8') as log:
        for run in RUNS:
            log.write(f"{run['id']} вариант {run['variant']}: {run['name']}\nВВОД:\n")
            log.write(run['input'] or '[EOF]\n')
            log.write('ВЫВОД:\n'+run['stdout'])
            log.write(f"\nSTDERR: {run['stderr']!r}\nКод: {run['returncode']}\nПройден: {run['passed']}\n\n")
    print((ROOT / 'unittest_output.txt').read_text(encoding='utf-8'))
    print(json.dumps(metadata,ensure_ascii=False,indent=2))
    sys.exit(0 if result.wasSuccessful() else 1)
